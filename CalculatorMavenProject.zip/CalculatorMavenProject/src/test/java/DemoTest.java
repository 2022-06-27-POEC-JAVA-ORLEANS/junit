import org.junit.jupiter.api.Test;

public class DemoTest {

    @Test
    void testDemo() {
        System.out.println("Demo Test");
    }

}
